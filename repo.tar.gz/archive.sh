rm repo.tar.gz
git archive --format=tar.gz --output=repo.tar.gz HEAD
ls repo.tar.gz -l